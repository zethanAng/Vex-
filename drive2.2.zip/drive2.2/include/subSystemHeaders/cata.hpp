#include "main.h"


void setCata(int power);
void setCataMotors();