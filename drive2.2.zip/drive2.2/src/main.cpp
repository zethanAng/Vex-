#include "main.h"
#include "lemlib/api.hpp"
#define DIGITAL_SENSOR_PORT 'A' 
#define DIGITAL_SENSOR_PORT2 'E' 
#define DIGITAL_SENSOR_PORT3 'B' 
 pros::Motor driveLeftFront(13, pros::E_MOTOR_GEAR_BLUE, 1, pros::E_MOTOR_ENCODER_COUNTS);
 pros::Motor driveLeftBack(15, pros::E_MOTOR_GEAR_BLUE, 1, pros::E_MOTOR_ENCODER_COUNTS);
 pros::Motor driveLeftMiddle(14, pros::E_MOTOR_GEAR_BLUE,1,pros::E_MOTOR_ENCODER_COUNTS);   
 pros::Motor driveRightMiddle(4, pros::E_MOTOR_GEAR_BLUE,0,pros::E_MOTOR_ENCODER_COUNTS);
 pros::Motor driveRightFront(3, pros::E_MOTOR_GEAR_BLUE, 0, pros::E_MOTOR_ENCODER_COUNTS);
 pros::Motor driveRightBack(5, pros::E_MOTOR_GEAR_BLUE, 0, pros::E_MOTOR_ENCODER_COUNTS);
pros::MotorGroup lsm({driveLeftFront, driveLeftBack, driveLeftMiddle});
pros::MotorGroup rsm({driveRightFront, driveRightBack, driveRightMiddle});

pros::ADIDigitalOut wingsLeft (DIGITAL_SENSOR_PORT,false);
pros::ADIDigitalOut wingsRight (DIGITAL_SENSOR_PORT2,false);
pros::ADIDigitalOut sidePiston(DIGITAL_SENSOR_PORT3,false);

lemlib::Drivetrain drivetrain (&lsm, // left motor group
                              &rsm, // right motor group
                              12, // 10 inch track width
                              3.25, // using new 3.25" omnis
                              360, // drivetrain rpm is 360
                              8 // chase power is 2. If we had traction wheels, it would have been 8
);
 
// left tracking wheel encoder
//pros::ADIEncoder left_enc('A', 'B', true); // ports A and B, reversed
// right tracking wheel encoder
//pros::Rotation right_rot(1, false); // port 1, not reversed
// back tracking wheel encoder
//pros::ADIEncoder back_enc('C', 'D', false); // ports C and D, not reversed
// inertial sensor
pros::Imu imu(2); // port 2

/*
// left tracking wheel
lemlib::TrackingWheel left_tracking_wheel(&left_enc, 2.75, -4.6); // 2.75" wheel diameter, -4.6" offset from tracking center
// right tracking wheel
lemlib::TrackingWheel right_tracking_wheel(&right_rot, 2.75, 1.7); // 2.75" wheel diameter, 1.7" offset from tracking center
lemlib::TrackingWheel back_tracking_wheel(&back_enc, 2.75, 4.5); // 2.75" wheel diameter, 4.5" offset from tracking center
 
*/
// odometry struct
lemlib::OdomSensors sensors {
    nullptr, 
    nullptr, 
    nullptr,  
    nullptr,
    &imu // inertial sensor
};
// forward/backward PID
/*
lemlib::ControllerSettings lateralController {
    34, // kP
    33, // kD
    1, // smallErrorRange
    100, // smallErrorTimeout
    3, // largeErrorRange
    500, // largeErrorTimeout
    20 // slew rate
};
 
// turning PID
lemlib::ControllerSettings angularController {
    4, // kP
    34, // kD
    1, // smallErrorRange
    100, // smallErrorTimeout
    3, // largeErrorRange
    500, // largeErrorTimeout
    20 // slew rate
};
*/
lemlib::ControllerSettings lateralController {
    10, // kP
    30, // kD
    1, // smallErrorRange
    100, // smallErrorTimeout
    3, // largeErrorRange
    500, // largeErrorTimeout
    20 // slew rate
};
 
// turning PID
lemlib::ControllerSettings angularController {
    2, // kP
    10, // kD
    1, // smallErrorRange
    100, // smallErrorTimeout
    3, // largeErrorRange
    500, // largeErrorTimeout
    20 // slew rate
};
lemlib::Chassis chassis(drivetrain, lateralController, angularController, sensors);

void on_center_button() {
	static bool pressed = false;
	pressed = !pressed;
	if (pressed) {
		pros::lcd::set_text(2, "I was pressed!");
	} else {
		pros::lcd::clear_line(2);
	}
}
void initialize() {
    pros::lcd::initialize(); // initialize brain screen
    chassis.calibrate(); // calibrate sensors
     // X: 0, Y: 0, Heading: 0
    pros::Task screenTask([&]() {
        lemlib::Pose pose(0, 0, 0);
        while (true) {
            // print robot location to the brain screen
            pros::lcd::print(0, "X: %f", chassis.getPose().x); // x
            pros::lcd::print(1, "Y: %f", chassis.getPose().y); // y
            pros::lcd::print(2, "Theta: %f", chassis.getPose().theta); // heading
            // log position telemetry
            lemlib::telemetrySink()->info("Chassis pose: {}", chassis.getPose());
            // delay to save resources
            pros::delay(50);
        }
    });
}

void disabled() {}

void competition_initialize() {}

void opcontrol() {
    bool sideOn = false;
    bool leftOn = false;
    bool rightOn = false;
     while (true) {
         if (controller.get_digital_new_press(DIGITAL_L1)) {
            leftOn = !leftOn;
             wingsLeft.set_value(leftOn);
         }
         if (controller.get_digital_new_press(DIGITAL_R1)) {
             rightOn = !rightOn; 
             wingsRight.set_value(rightOn);
         }
         if(controller.get_digital_new_press(DIGITAL_X)){
             sidePiston.set_value(!sideOn);
         }
 		setDriveMotors();
        setIntakeMotors();
        setCataMotors();
        pros::delay(1);
     }
}

void autonomous() { 
    //chassis.setPose(0,0,0,false);
    //chassis.moveTo(0,10,0,4000,true);
    /*
    chassis.setPose(-28.947,-54.718,270,false);
    chassis.moveTo(-45.063,-55.016,270,4000,true);
    wingsLeft.set_value(true);
    setIntake(100);
    pros::delay(1000);
    setIntake(0);
    chassis.moveTo(-62.373,-46.958,0,4000,true);
    chassis.moveTo(-62.373,-48,0,4000,true);
    chassis.moveTo(-62.373,-46.958,0,4000,true);
    wingsLeft.set_value(false);
    chassis.turnTo(-62.373,-60,4000,true);
    chassis.moveTo(-6.636,-57.404,90,4000,true);
    */
    chassis.setPose(28.974,-54.342,90);
    chassis.moveTo(45.687,-54.641,90,4000,true);
    wingsRight.set_value(true);
    setIntake(-300);
    pros::delay(1000);
    setIntake(0);
    chassis.moveTo(62.4,-29.571,0,4000,true);
    wingsRight.set_value(false);
    chassis.turnTo(62.102,-40.016,4000,true);
    chassis.moveTo(62.102,-40.016,180,4000,true);
    chassis.turnTo(13.045,-26.881,4000);
    chassis.moveTo(13.045,-26.881,285,4000,true);
    setIntake(600);
    pros::delay(2000);
    setIntake(0);
    chassis.turnTo(41.509,-13.156,4000,true);
    setIntake(-600);
    pros::delay(2000);
    setIntake(0);
    chassis.turnTo(8.679,-9.873,4000,true);
    chassis.moveTo(8.679,-9.873,347,4000,true);
    setIntake(600);
    pros::delay(2000);
    setIntake(0);
    chassis.turnTo(42.703,4.154,4000,true);
    wingsLeft.set_value(true);
    wingsRight.set_value(true);
    chassis.moveTo(41.807,-4.799,90,4000,true);
}
