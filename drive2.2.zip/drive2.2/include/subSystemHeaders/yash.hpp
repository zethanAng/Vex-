#include "main.h"

void setYash(int power);
void setYashMotors();
