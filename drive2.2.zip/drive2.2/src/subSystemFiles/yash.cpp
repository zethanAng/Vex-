#include "main.h"

bool rightButtonPressed = false;


void setYash(int power) {
    yash = power;
}

void setYashMotors() {
    // yash.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);

    if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_LEFT)) {
        setYash(-70);
        rightButtonPressed = false;  
    } else if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_RIGHT)) {
        rightButtonPressed = !rightButtonPressed;

        if (rightButtonPressed) {
            setYash(100);
        } else {
            setYash(0);
        }
    } else {
        setYash(0);
        
        rightButtonPressed = false;  
    }
}

// #include "main.h"

// //helper
// void setYash(int power ){
//     yash = power;
// }

// void setYashMotors(){


//              if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_LEFT)) {
//             setYash(-70);
//             }
//              else if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_RIGHT)) {
//             setYash(70);
//             }
//             else{setYash(0);}
// }