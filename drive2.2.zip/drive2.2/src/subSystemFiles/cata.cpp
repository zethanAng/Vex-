#include "main.h"

//helper
void setCata(int power ){
    cata = power;
}

void setCataMotors(){

     if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_A)) {
        setCata(-70);

     }
     else{setCata(0);}
}


