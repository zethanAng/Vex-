#include "main.h"

bool intakeRunning = false;
int intakePower = 0;

void setIntake(int power) {
    intake = power;
}

void setIntakeMotors(){
     if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_L2) && !intakeRunning){
         setIntake(600);
         intakeRunning = true; 
     }
     else if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_R2) && !intakeRunning){
         setIntake(-600);
         intakeRunning = true; 
     }
     else if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_L2) && intakeRunning){
         setIntake(0);
         intakeRunning = false;
     }
     else if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_R2) && intakeRunning){
        setIntake(0);
        intakeRunning = false; 
     }
    else{setIntake(0);}
    pros::delay(10);
}
//void setIntakeMotors() {
// 
//    if (intakeRunning) {
//        if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_DOWN)) {
//            intakePower = 600;
//        } else if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_UP)) {
//            intakePower = (intakePower == 0) ? -600 : 0;
//        }
//    }

//    setIntake(intakePower);
//}