#include "main.h"

//Motors
extern pros::Motor lift;
extern pros::Motor angler;
extern pros::Motor intake;
extern pros::Motor driveLeftBack;
extern pros::Motor driveLeftFront;
extern pros::Motor driveLeftMiddle;
extern pros::Motor driveRightMiddle;
extern pros::Motor driveRightFront;
extern pros::Motor driveRightBack;
extern pros::Motor cata;
extern pros::Motor yash;

//Controller
extern pros::Controller controller;

//Miscellaneous
