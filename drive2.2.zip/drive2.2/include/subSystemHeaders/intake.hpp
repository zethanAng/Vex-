#include "main.h"

//helper
void setIntake(int power);

//driverControl
void setIntakeMotors();