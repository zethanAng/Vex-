#include "main.h"


//helper
void setLift(int power);

//driverControl
void setLiftMotor();